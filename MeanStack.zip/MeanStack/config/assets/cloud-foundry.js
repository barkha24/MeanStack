'use strict';

module.exports = {};
